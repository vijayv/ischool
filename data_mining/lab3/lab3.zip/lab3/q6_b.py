
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import sklearn
from sklearn import metrics
from sklearn.cluster import KMeans
import math


# In[2]:

df = pd.read_csv("yelp_reviewers.txt", delimiter="|")
# print df.head()


# In[8]:

def fit_k_means(k_values, X):
    for k in k_values:
        k_means = sklearn.cluster.KMeans(n_clusters=k)
        k_means.fit(X)
        ss = sklearn.metrics.silhouette_score(X, k_means.labels_, metric='euclidean')
        print "K: %s -> SS: %s" % (k, ss)
        return k_means.labels_

# In[ ]:

k_values = [5]
# print df[["q4", "q5", "q6"]].head()
#q4_features = df[["q8", "q9", "q10", "q11", "q12", "q13"]].dropna().values
f = lambda x: math.log(float(x))
df["q17"] = df.q17.astype(float)
df[df["q17"] == 0.0] = np.nan
# df["q17"]=df[["q17"]].apply(f)
subdf = df[["q8", "q9", "q10", "q11", "q12", "q13", "q14", "q16a", "q16b", "q16c", "q16d", "q16e", "q16f", "q16g", "q16h", "q16i", "q17"]]
# print q2_features.shape, type(q2_features)
subdf = subdf.dropna()
# print type(df["q17"][0])
subdf.q17 = np.log(subdf["q17"])
q6_features = subdf[["q8", "q9", "q10", "q11", "q12", "q13", "q16a", "q16b", "q16c", "q16d", "q16e", "q16f", "q16g", "q16h", "q16i", "q17"]].values

labels = fit_k_means(k_values, q6_features)
subdf["labels"] = labels
subdf["count"] = 1
y = subdf.groupby('labels').sum()
y["av_star"] = y["q14"]/y["count"]
print y["av_star"]
# In[ ]:



