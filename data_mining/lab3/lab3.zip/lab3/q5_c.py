
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import sklearn
from sklearn import metrics
from sklearn.cluster import KMeans


# In[2]:

df = pd.read_csv("yelp_reviewers.txt", delimiter="|")
#print df.head()
#print df.sum()

# In[8]:

def fit_k_means(k_values, X):
#for k in k_values:
	k_means = sklearn.cluster.KMeans(n_clusters=8)
	k_means.fit(X)
	print type(k_means.labels_)
	return k_means.labels_
# In[ ]:

k_values = range(2,9)
# print df[["q4", "q5", "q6"]].head()
newdf = df[["q4", "q5", "q6", "q11", "q12", "q13"]].dropna()
q5_features = newdf[["q11", "q12", "q13"]].values
#print q4_features.shape, type(q4_features)
# print df.shape, newdf.shape
labels = fit_k_means(k_values, q5_features)
df1 = pd.DataFrame()
df1['funny']=newdf["q5"]
df1['useful']=newdf["q6"]
df1['cool']=newdf["q4"]
# df2=df1.dropna()

df1['labels']=labels
print df1
y = df1.groupby('labels').sum()
y["usebyfunny"] = y["useful"]/y["funny"]
y["usebycool"] = y["useful"]/y["cool"]
y["coolbyfunny"] = y["cool"]/y["funny"]

print y
print df1[df1['labels'] == 1].count()
# In[ ]:
