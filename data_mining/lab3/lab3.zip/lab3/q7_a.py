
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import sklearn
from sklearn import metrics
from sklearn.cluster import KMeans
import math


# In[2]:

df = pd.read_csv("yelp_reviewers.txt", delimiter="|")
# print df.head()


# In[8]:

def fit_k_means(k_values, X):
    for k in k_values:
        k_means = sklearn.cluster.KMeans(n_clusters=k)
        k_means.fit(X)
        ss = sklearn.metrics.silhouette_score(X, k_means.labels_, metric='euclidean')
        print "K: %s -> SS: %s" % (k, ss)

# In[ ]:

k_values = range(2,9)
# print df[["q4", "q5", "q6"]].head()
#q4_features = df[["q8", "q9", "q10", "q11", "q12", "q13"]].dropna().values


df["q17"] = df.q17.astype(float)
df[df["q17"] == 0.0] = np.nan
# df["q17"]=df[["q17"]].apply(f)
subdf = df[["q8", "q9", "q10", "q11", "q12", "q13", "q16a", "q16b", "q16c", "q16d", "q16e", "q16f", "q16g", "q16h", "q16i", "q17", \
"q18_group2", "q18_group3", "q18_group5", "q18_group6", "q18_group7", "q18_group11", "q18_group13", "q18_group14", "q18_group15", \
"q18_group16_a", "q18_group16_b", "q18_group16_c", "q18_group16_d", "q18_group16_e", "q18_group16_f", "q18_group16_g", "q18_group16_h"]]# print q2_features.shape, type(q2_features)
subdf = subdf.dropna()
# print type(df["q17"][0])
subdf.q17 = np.log(subdf["q17"])
print subdf.shape
q6_features = subdf[["q8", "q9", "q10", "q11", "q12", "q13", "q16a", "q16b", "q16c", "q16d", "q16e", "q16f", "q16g", "q16h", "q16i", "q17"]].values

fit_k_means(k_values, q6_features)

# In[ ]:



