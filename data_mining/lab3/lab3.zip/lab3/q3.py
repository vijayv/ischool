
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import sklearn
from sklearn import metrics
from sklearn.cluster import KMeans


# In[2]:

df = pd.read_csv("yelp_reviewers.txt", delimiter="|")
print df.head()


# In[8]:

def fit_k_means(k_values, X):
    for k in k_values:
        k_means = sklearn.cluster.KMeans(n_clusters=k)
        k_means.fit(X)
        ss = sklearn.metrics.silhouette_score(X, k_means.labels_[:10000], metric='euclidean')
        print "K: %s -> SS: %s" % (k, ss)


# In[ ]:

k_values = range(2,9)
# print df[["q4", "q5", "q6"]].head()
q3_features = df[["q8", "q9", "q10"]].dropna().values
# print q2_features.shape, type(q2_features)

fit_k_means(k_values, q3_features)


# In[ ]:



